import pymysql
print(pymysql.__file__)
pymysql.install_as_MySQLdb()